
![Logo](https://cdn.discordapp.com/icons/988873429929295942/db6e253bcf5cdebdff81f5ae04d3cd4d.png?size=4096)


# Globy Gen

rip gen fr. (promotion ended like 4 month ago idk)

## License

[MIT](https://choosealicense.com/licenses/mit/)

### <img src="https://c.tenor.com/-iJ1olfz7qsAAAAC/boost-discord.gif" width="50"> Features 

- very proffesional look (jk)
- very fast (profit)
- fre money :shock:!!1
- people love you


## Installation

- Install python (if you dont have it) 
- Run ```pip install urllib3 requests colorama termcolor httpx discord``` in console
- Run ```python globy.py``` in console
- Choose Promo Gen and enjoy. 
    
## Authors

- [me](https://www.github.com/bbambiku)
- memexurer


## Used By

- polsat tv
- your mom
- verified pornhub users
- me ofc


## Support

For support join https://discord.gg/eutopia and contact developer/owner.

